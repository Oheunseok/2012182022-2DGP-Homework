from pico2d import*
import random
import time

class Candy:
    image = None
    eat_sound = None
    def __init__(self,):
        self.x, self.y = random.randint(1366, 9600),70
        if Candy.image == None:
            Candy.image =load_image('resource\\item\\size1\\star_red.png')
        if Candy.eat_sound == None:
            Candy.eat_sound = load_wav('resource\\music\\g_jelly.wav')
            Candy.eat_sound.set_volume(32)
    def update(self, frame_time):
        self.x-=(300*frame_time)
        self.y

        pass
    def eat(self, candy):
        self.eat_sound.play()

    def draw(self):
        self.image.draw(self.x,self.y)

    def draw_bb(self):
        draw_rectangle(*self.get_bb())
        pass

    def get_bb(self):
        return self.x-14, self.y-14, self.x+14, self.y+14


class HpItem:
    image = None
    eat_sound = None
    def __init__(self,):
        self.x, self.y = random.randint(1366, 9600),200
        if HpItem.image == None:
            HpItem.image =load_image('resource\\item\\hp.png')
        if HpItem.eat_sound == None:
            HpItem.eat_sound = load_wav('resource\\music\\hpitem.wav')
            HpItem.eat_sound.set_volume(32)
    def update(self, frame_time):
        self.x-=(300*frame_time)
        self.y

        pass
    def eat(self, hpup):
        self.eat_sound.play()

    def draw(self):
        self.image.draw(self.x,self.y)

    def draw_bb(self):
        draw_rectangle(*self.get_bb())
        pass

    def get_bb(self):
        return self.x-14, self.y-14, self.x+14, self.y+14
