from pico2d import *

import game_framework


import scroll_state


name = "TitleState"
image = None
button = None
button_push = None
mx, my= 0,0
def enter():
    global image, button, button_push
    image = load_image('resource\\ui\\title.png')
    button = load_image('resource\\ui\\start_button.png')
    button_push = load_image('resource\\ui\\start_button_push.png')

def exit():
    global image, button, button_push
    del (image)
    del (button)
    del (button_push)

def pause():
    pass

def resume():
    pass


def handle_events(frame_time):
    global mx,my
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_MOUSEMOTION:
            mx, my = event.x, 450 - event.y
        elif (event.type, event.button)  == (SDL_MOUSEBUTTONDOWN, SDL_BUTTON_LEFT):
                if (1015< mx <1175 and 100<my<160):
                    game_framework.change_state(scroll_state)
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
                game_framework.quit()



def update(frame_time):
    pass


def draw(frame_time):
    global mx,my
    clear_canvas()
    image.draw(683,225)
    if (1015< mx <1175 and 100<my<160):
        button_push.draw(1094,128)
    else:button.draw(1094,128)
    update_canvas()



