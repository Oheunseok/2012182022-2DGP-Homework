from pico2d import *
import time
import game_framework
import pause_state
import Boss
import json
import os
from character import Dog, Cat  # import Boy class from boy.py
from background import Background, Background2, MovingBrick, Bomb, Platform, UI
from bullet import Bullet
from item import Candy, HpItem
import GameOver

name = "scroll_state"
check = 0
font = None
cat = None
dog = None
bomb = None
background = None
background2 = None
movebrick = None
bullet = None
item = None
ui = None
platform = None
num = 0
unhit_time = 0
hpitem = 0
x_list = []


def record():
    if os.path.exists('score.txt'):
        with open('score.txt', 'r') as f:
            score_list = json.load(f)

    score = {"x": movebrick[0].x, "length": 50}

    score_list.append(score)

    with open('score.txt', 'w') as f:
        json.dump(score_list, f)


def create_world():
    global cat, background, background2, movebrick, font, dog, bomb, bullet, item, platform, ui, hpitem
    movebrick = []
    brick_list = []
    with open('brick.txt', 'r') as f:
        brick_list = json.load(f)
    for name in brick_list:
        # x_list.append(name['x'])
        movebrick.append(MovingBrick(name['x']))

    font = load_font('NanumPen.TTF', 50)
    background = Background(1366, 450)
    background2 = Background2(1366, 450)
    cat = Cat()
    dog = Dog()
    bomb = Bomb()
    platform = Platform(1366, 45)

    bullet = []
    ui = UI()
    item = [Candy() for candy in range(100)]
    hpitem = [HpItem() for hpup in range(5)]


def destroy_world():
    global cat, background, background2, movebrick, dog, bomb, bullet, item, platform, ui, hpitem
    del (item)
    del (dog)
    del (cat)
    del (background)
    del (background2)
    del (bomb)
    del (movebrick)
    del (bullet)
    del (platform)
    del (ui)
    del (hpitem)


def enter():
    game_framework.reset_time()
    create_world()


def exit():
    destroy_world()
    # close_canvas()


def pause():
    pass


def resume():
    pass


def handle_events(frame_time):
    global bullet, num

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        else:
            if (event.type, event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
                game_framework.quit()
            elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_SPACE):
                if dog.state == (0 or 2):
                    bomb.starboom(-dog.x, dog.y)
                    bomb.bomb_time = 0
                elif dog.state == (1 or 3):
                    bomb.starboom(dog.x, dog.y)
                    bomb.bomb_time = 0
            elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_x):
                bullet.append(Bullet())
                bullet[num].starboom(dog.x, dog.y)
                num += 1
            elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_p):
                game_framework.push_state(pause_state)
            elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_t):
                game_framework.push_state(Boss)
            else:
                dog.handle_event(event)


def collide(a, b):
    left_a, bottom_a, right_a, top_a = a.get_bb()
    left_b, bottom_b, right_b, top_b = b.get_bb()

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a < bottom_b: return False
    if bottom_a > top_b: return False

    return True


def update(frame_time):
    global unhit_time

    cat.update(frame_time)

    ui.update(frame_time)
    dog.update(frame_time)

    for i in bullet:
        i.update(frame_time)

    bomb.update(frame_time)

    if background.next_stage == 0:
        background.update(frame_time)
    elif background.next_stage == 1:
        game_framework.push_state(Boss)

    platform.update(frame_time)

    for wall in movebrick:
        if 600 <= wall.x < 700:
            if collide(dog, wall):
                dog.hit_func()

        wall.update(frame_time)

    for candy in item:
        candy.update(frame_time)
    for hpup in hpitem:
        hpup.update(frame_time)

    for candy in item:
        if 600 <= candy.x < 700:
            if collide(dog, candy):
                item.remove(candy)
                candy.eat(candy)
                dog.score += 50
    for hpup in hpitem:
        if 600 <= hpup.x < 700:
            if collide(dog, hpup):
                hpitem.remove(hpup)
                hpup.eat(hpup)
                dog.score += 50
                dog.hp += 1

    if dog.state == Dog.DIE:
        game_framework.change_state(GameOver)


def draw(frame_time):
    clear_canvas()
    if background.next_stage == False:
        background.draw()
    elif background.next_stage == True:
        background2.draw()
    dog.draw()
    bomb.draw()
    platform.draw()
    for i in bullet:
        i.draw()
    cat.draw()
    font.draw(600, 430, '2012182022', (255, 255, 255))
    font.draw(130, 320, '%d' % bomb.bomb_count, (255, 255, 255))
    font.draw(1150, 430, 'Score %3.2f' % dog.score, (255, 255, 255))
    for wall in movebrick:
        wall.draw()
    for candy in item:
        if 0 <= candy.x < 1366:
            candy.draw()
    for hpup in hpitem:
        if 0 <= hpup.x < 1366:
            hpup.draw()
    ui.hpdraw(dog.hp)
    ui.draw()

    update_canvas()
