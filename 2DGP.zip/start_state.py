from pico2d import *
import game_framework

import title_state

name = "StartState"
splash = None
splashbg = None
katalk = None
frame = 0
logo_time = 0.0
def enter():
    global splash, splashbg, katalk
    open_canvas(1366,450)
    splash = load_image('resource\\ui\\start.png')
    splashbg = load_image('resource\\ui\\splashbg.png')
    katalk = load_wav('resource\\music\\katalk.wav')
    katalk.set_volume(32)
    katalk.play()



def exit():
    global splash, splashbg, katalk
    del(splash)
    del(splashbg)
    del(katalk)
    close_canvas()

def update(frame_time):
    global name
    global logo_time

    if (logo_time > 3):
        logo_time = 0
        game_framework.push_state(title_state)

    logo_time += frame_time

def draw(frame_time):
    global splash, alpha, logo_time, splashbg

    clear_canvas()
    splashbg.draw(683,225)
    if (logo_time<2):
        splash.opacify(logo_time * 0.5)
    else:
        splash.opacify(1.0 - (logo_time * 0.6))
    splash.draw(683,225)
    update_canvas()

def handle_events(frame_time):
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        else:
            if (event.type, event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
                game_framework.quit()
            elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_SPACE):
                game_framework.push_state(title_state)


def pause(): pass
def resume(): pass




