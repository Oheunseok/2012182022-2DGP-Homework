from pico2d import *
import random


class Background:
    PIXEL_PER_METER = (10.0 / 0.3)  # 10 pixel 30 cm
    SCROLL_SPEED_KMPH = 30.0  # Km / Hour
    SCROLL_SPEED_MPM = (SCROLL_SPEED_KMPH * 1000.0 / 60.0)
    SCROLL_SPEED_MPS = (SCROLL_SPEED_MPM / 60.0)
    SCROLL_SPEED_PPS = (SCROLL_SPEED_MPS * PIXEL_PER_METER)

    def __init__(self, w, h):
        self.image = load_image('Resource\\map\\stage3.png')
        self.speed = 0
        self.left = 0
        self.screen_width = w
        self.screen_height = h
        self.world_shift = 0
        self.next_stage = 0
        self.bgm = load_music('Resource\\music\\bgm_main3.ogg')
        self.bgm.set_volume(64)
        self.bgm.repeat_play()

    def draw(self):
        x = int(self.left)
        w = min(self.image.w - x, self.screen_width)
        self.image.clip_draw_to_origin(x, 0, w, self.screen_height, 0, 0)
        self.image.clip_draw_to_origin(0, 0, self.screen_width - w, self.screen_height, w, 0)

    def update(self, frame_time):
        self.left = (self.left + frame_time * self.speed) % self.image.w
        self.speed = Background.SCROLL_SPEED_PPS
        if self.world_shift < 10000:
            self.world_shift += (300 * frame_time)
        elif self.world_shift >= 10000:
            pass
            self.next_stage = True
            # print("%d" % self.world_shift)


class Background2:
    PIXEL_PER_METER = (10.0 / 0.3)  # 10 pixel 30 cm
    SCROLL_SPEED_KMPH = 30.0  # Km / Hour
    SCROLL_SPEED_MPM = (SCROLL_SPEED_KMPH * 1000.0 / 60.0)
    SCROLL_SPEED_MPS = (SCROLL_SPEED_MPM / 60.0)
    SCROLL_SPEED_PPS = (SCROLL_SPEED_MPS * PIXEL_PER_METER)

    def __init__(self, w, h):
        self.image = load_image('Resource\\map\\stage1.png')
        self.speed = 0
        self.left = 0
        self.screen_width = w
        self.screen_height = h
        self.world_shift = 0

    def draw(self):
        x = int(self.left)
        w = min(self.image.w - x, self.screen_width)
        self.image.clip_draw_to_origin(x, 0, w, self.screen_height, 0, 0)
        self.image.clip_draw_to_origin(0, 0, self.screen_width - w, self.screen_height, w, 0)

    def update(self, frame_time):
        self.left = (self.left + frame_time * self.speed) % self.image.w
        self.speed = Background2.SCROLL_SPEED_PPS


class BossStage:
    PIXEL_PER_METER = (10.0 / 0.3)  # 10 pixel 30 cm
    SCROLL_SPEED_KMPH = 30.0  # Km / Hour
    SCROLL_SPEED_MPM = (SCROLL_SPEED_KMPH * 1000.0 / 60.0)
    SCROLL_SPEED_MPS = (SCROLL_SPEED_MPM / 60.0)
    SCROLL_SPEED_PPS = (SCROLL_SPEED_MPS * PIXEL_PER_METER)
    BGSCROLL_SPEED_KMPH = 20.0

    def __init__(self, w, h):
        self.image = load_image('Resource\\map\\mali2.png')
        self.bgm = load_music('Resource\\music\\boss.mp3')
        self.bgm.set_volume(32)
        self.bgm.repeat_play()
        self.speed = 0
        self.left = 0
        self.screen_width = w
        self.screen_height = h
        self.world_shift = 0

    def draw(self):
        x = int(self.left)
        w = min(self.image.w - x, self.screen_width)

        self.image.clip_draw_to_origin(x, 0, w, self.screen_height, 0, 0)
        self.image.clip_draw_to_origin(0, 0, self.screen_width - w, self.screen_height, w, 0)

    def update(self, frame_time):
        self.left = (self.left + frame_time * self.speed) % self.image.w

        self.speed = BossStage.SCROLL_SPEED_PPS


class Platform:
    PIXEL_PER_METER = (10.0 / 0.3)  # 10 pixel 30 cm
    SCROLL_SPEED_KMPH = 30.0  # Km / Hour
    SCROLL_SPEED_MPM = (SCROLL_SPEED_KMPH * 1000.0 / 60.0)
    SCROLL_SPEED_MPS = (SCROLL_SPEED_MPM / 60.0)
    SCROLL_SPEED_PPS = (SCROLL_SPEED_MPS * PIXEL_PER_METER)

    def __init__(self, w, h):
        self.image = load_image('Resource\\ui\\platform2.png')
        self.speed = 0
        self.left = 0
        self.screen_width = w
        self.screen_height = h

    def draw(self):
        x = int(self.left)
        w = min(self.image.w - x, self.screen_width)
        self.image.clip_draw_to_origin(x, 0, w, self.screen_height, 0, 0)
        self.image.clip_draw_to_origin(0, 0, self.screen_width - w, self.screen_height, w, 0)

    def update(self, frame_time):
        self.left = (self.left + frame_time * self.speed) % self.image.w
        self.speed = Platform.SCROLL_SPEED_PPS


class BossPlatform:
    PIXEL_PER_METER = (10.0 / 0.3)  # 10 pixel 30 cm
    SCROLL_SPEED_KMPH = 30.0  # Km / Hour
    SCROLL_SPEED_MPM = (SCROLL_SPEED_KMPH * 1000.0 / 60.0)
    SCROLL_SPEED_MPS = (SCROLL_SPEED_MPM / 60.0)
    SCROLL_SPEED_PPS = (SCROLL_SPEED_MPS * PIXEL_PER_METER)

    def __init__(self, w, h):
        self.image = load_image('Resource\\ui\\platform3.png')
        self.speed = 0
        self.left = 0
        self.screen_width = w
        self.screen_height = h

    def draw(self):
        x = int(self.left)
        w = min(self.image.w - x, self.screen_width)
        self.image.clip_draw_to_origin(x, 0, w, self.screen_height, 0, 0)
        self.image.clip_draw_to_origin(0, 0, self.screen_width - w, self.screen_height, w, 0)

    def update(self, frame_time):
        self.left = (self.left + frame_time * self.speed) % self.image.w
        self.speed = BossPlatform.SCROLL_SPEED_PPS


class UI:
    def __init__(self):
        self.image = load_image('Resource/\\ui\\UI.png')
        self.hpbg = load_image('Resource\\ui\\hpbar_bg.png')
        self.hp = load_image('Resource\\ui\\hpbar.png')
        self.frame = 0

    def draw(self):
        self.image.draw(683, 370)

    def update(self, frame_time):
        self.frame = (self.frame + 1) % 3

    def hpdraw(self, hp):
        self.hpbg.draw(550, 390)
        self.hp.clip_draw_to_origin(0, self.frame * 29, 89 * hp, 29, 100, 375)


class Bomb:
    bomb_sound = None

    def __init__(self):
        self.image = load_image('Resource\\weapon\\bomb3.png')
        self.speed = 100  # 100pixel per second
        self.x, self.y = 100, 100
        self.throw = False
        self.thx, self.thy = 0, 0
        self.bomb_time = 0
        self.frame = random.randint(0, 5)
        self.bomb_count = 3
        if Bomb.bomb_sound == None:
            Bomb.bomb_sound = load_wav('Resource\\music\\bomb.wav')
            Bomb.bomb_sound.set_volume(32)

    def bombsound(self, bomb):
        self.bomb_sound.play()

    def starboom(self, dogx, dogy):
        self.throw = True
        self.thx, self.thy = dogx, dogy

    def update(self, frame_time):
        self.bomb_time += frame_time
        self.frame = (self.frame + 1) % 5
        self.x = self.thx + 500
        self.y = self.thy
        if 0 < self.bomb_count <= 3:
            if self.throw == True:
                if self.bomb_time > 0.5:
                    self.throw = False
                    self.thx, self.thy = -100, -100
                    self.bomb_count -= 1

    def draw(self):
        if 0 < self.bomb_count <= 3:
            if self.throw == True:
                self.image.clip_draw(self.frame * 100, 0, 100, 100, self.x, self.y)


        elif self.bomb_count < 0:
            self.throw = False

    def draw_bb(self):
        draw_rectangle(*self.get_bb())
        pass

    def get_bb(self):
        return self.x - 50, self.y - 50, self.x + 50, self.y + 50


class MovingBrick:
    image = None

    def __init__(self, x):
        self.create_time = 1000

        self.x = x
        self.y = 115
        self.name = 'noname'

        if MovingBrick.image == None:
            MovingBrick.image = load_image('Resource\\brick\\wall2.png')

    def update(self, frame_time):
        self.x -= (300 * frame_time)

    def draw(self):
        self.image.draw(self.x, self.y)

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):
        return self.x - 20, self.y - 70, self.x + 20, self.y + 70


class BossBrick:
    image = None

    def __init__(self):
        self.create_time = 1000
        self.x = random.randint(1000, 100000)
        self.y = 115
        self.name = 'noname'

        if BossBrick.image == None:
            BossBrick.image = load_image('Resource\\brick\\wall3.png')

    def update(self, frame_time):
        self.x -= (300 * frame_time)

    def draw(self):
        self.image.draw(self.x, self.y)

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):
        return self.x - 20, self.y - 70, self.x + 20, self.y + 70


class Skill:
    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 1
    skillimage = None

    def __init__(self):
        self.create_time = 1000
        self.x = 0
        self.y = 45
        self.frame = 1
        self.total_frames = 0.0
        self.cooltime = 0
        if Skill.skillimage == None:
            Skill.skillimage = load_image('Resource\\map\\firewall.png')

    def update(self, frame_time):
        self.cooltime += frame_time
        self.total_frames += Skill.FRAMES_PER_ACTION * Skill.ACTION_PER_TIME * frame_time
        self.frame = int(self.total_frames) % 2

    def draw(self):
        self.skillimage.clip_draw_to_origin(0, self.frame * 225, 1366, 225, self.x, self.y)

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):
        return self.x + 650, self.y, self.x + 700, self.y + 150

