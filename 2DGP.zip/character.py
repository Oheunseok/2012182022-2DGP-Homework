from pico2d import *
import random
import time
from background import MovingBrick
import game_framework
#import GameOver


class Dog:
    PIXEL_PER_METER = (10.0 / 0.3)  # 10 pixel 30 cm
    RUN_SPEED_KMPH = 20.0  # Km / Hour
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    JUMP_SPEED_MPS = 20
    JUMP_SPEED_PPS = (JUMP_SPEED_MPS * PIXEL_PER_METER)
    v = 0
    jump_time = 0

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8

    image = None
    jump_sound = None
    collide_sound = None
    DUMMY, HIT, RUN, JUMP, DIE = 0, 1, 2, 3, 4

    def __init__(self):
        self.x, self.y = 683, 50
        self.frame = random.randint(0, 20)
        self.life_time = 0.0
        self.total_frames = 0.0
        self.xdir, self.ydir = 0, 0
        self.state = self.RUN
        self.parent = None
        self.score = 0
        self.hp = 10
        self.unhit = 0
        self.unhit_time = 0

        if Dog.image == None:
            Dog.image = load_image('Resource\\characters\\dog_run5.png')
        if Dog.jump_sound == None:
            Dog.jump_sound = load_wav('Resource\\music\\jump.wav')
            Dog.jump_sound.set_volume(32)
        if Dog.collide_sound == None:
            Dog.collide_sound = load_wav('Resource\\music\\collide.wav')
            Dog.collide_sound.set_volume(32)

    def hit_func(self):
        if self.unhit == 0:
            self.collide_sound.play()
            self.unhit = 1
            self.hp -= 1
            self.unhit_time = 2.0

    def update(self, frame_time):
        def clamp(minimum, x, maximum):
            return max(minimum, min(x, maximum))

        if self.unhit == 1:
            self.unhit_time -= frame_time
            if self.unhit_time <= 0:
                self.unhit = 0

        if self.state == self.HIT and self.y > 90: self.y -= 3

        self.life_time += frame_time
        distance = Dog.RUN_SPEED_PPS * frame_time
        self.total_frames += Dog.FRAMES_PER_ACTION * Dog.ACTION_PER_TIME * frame_time
        self.frame = int(self.total_frames) % 20
        self.x += (self.xdir * distance)
        self.y += (self.ydir * distance)
        self.x = clamp(300, self.x, 2700)
        self.y = clamp(90, self.y, 600)
        self.move = 0
        if self.state == self.JUMP:
            self.jump_time += frame_time
            self.v = self.JUMP_SPEED_PPS - self.jump_time * 1000
            self.y = 90 + self.JUMP_SPEED_PPS * self.jump_time - 1 / 2 * 1000 * self.jump_time * self.jump_time
            if self.y <= 90 and self.v <= 0:
                self.jump_time = 0
                self.v = self.JUMP_SPEED_PPS
                self.state = self.RUN
        if self.hp <= 0:
            self.state = self.DIE
            #game_framework.change_state(GameOver)

    def dettach(self):
        if (self.parent != None):
            self.parent = None

    def set_parent(self, movebrick):
        self.parent = movebrick
        self.rx = self.x - movebrick.x
        self.ry = self.y + 2 - movebrick.y

    def draw(self):
        if self.unhit == 1:
            if self.unhit_time % 0.5 <= 0.25:
                self.image.opacify(1.0)
            else:
                self.image.opacify(0.5)
        else:
            self.image.opacify(1.0)

        self.image.clip_draw(self.frame * 100, self.state * 100, 100, 100, self.x, self.y)

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):
        return self.x - 25, self.y - 40, self.x + 25, self.y + 40

    def handle_event(self, event):

        if (event.type, event.key) == (SDL_KEYDOWN, SDLK_UP):
            self.jump_sound.play()
            self.state = self.JUMP


class Boss:
    TIME_PER_ACTION = 1
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 3

    bossimage = None
    deadimage = None
    skillimage = None
    hit_sound = None
    STAND, DEAD, SKILL = 1, 2, 3

    def __init__(self):
        self.x, self.y = 1100, 45
        self.frame = 1
        self.life_time = 0.0
        self.total_frames = 0.0
        self.state = self.STAND
        self.parent = None
        self.score = 0
        self.hp = 1500
        self.unhit = False
        self.cooltime = 0

        if Boss.bossimage == None:
            Boss.bossimage = load_image('Resource\\monsters\\Boss1.png')
        if Boss.deadimage == None:
            Boss.deadimage = load_image('Resource\\monsters\\Bossdead.png')

    def update(self, frame_time):
        def clamp(minimum, x, maximum):
            return max(minimum, min(x, maximum))

        self.life_time += frame_time
        if self.state == self.STAND:
            self.total_frames += Boss.FRAMES_PER_ACTION * Boss.ACTION_PER_TIME * frame_time
            self.frame = int(self.total_frames) % 3
        if self.state == self.DEAD:
            self.total_frames += Boss.FRAMES_PER_ACTION * (Boss.ACTION_PER_TIME / Boss.TIME_PER_ACTION + 5) * frame_time
            self.frame = int(self.total_frames) % 5
        # if self.state == self.SKILL:
        #    self.cooltime+=frame_time
        #    self.total_frames += Boss.FRAMES_PER_ACTION * (Boss.ACTION_PER_TIME/ Boss.TIME_PER_ACTION+5) * frame_time
        #    self.frame = int(self.total_frames) % 2

        if self.hp <= 0:
            self.state = self.DEAD

    def draw(self):

        if self.state == self.STAND:
            self.bossimage.clip_draw_to_origin(self.frame * 250, 0, 250, 328, self.x, self.y)

        if self.state == self.DEAD:
            self.deadimage.clip_draw_to_origin(0, self.frame * 180, 328, 180, self.x, self.y)

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):
        return self.x + 100, self.y, self.x + 120, self.y + 328


class Cat:
    image = None

    LEFT_RUN, RIGHT_RUN = 0, 1

    def __init__(self):
        self.x, self.y = 1000, 90
        self.frame = random.randint(0, 8)
        self.dir = 1
        self.state = self.RIGHT_RUN
        self.hp = 100
        self.movex1 = 1300
        self.movex2 = 500
        if Cat.image == None:
            Cat.image = load_image('Resource\\monsters\\enemy_cat_sheet.png')

    def update(self, frame_time):
        if self.state == self.RIGHT_RUN:
            self.frame = (self.frame + 1) % 6
            self.x += (self.dir * 4)
        elif self.state == self.LEFT_RUN:
            self.frame = (self.frame + 1) % 6
            self.x += (self.dir * 4)
            self.x - 2
            self.movex1 -= 2
            self.movex2 -= 2
        if self.x > self.movex1:
            self.dir = -1
            self.x = self.movex1
            self.state = self.LEFT_RUN
        elif self.x < self.movex2:
            self.dir = 1
            self.x = self.movex2
            self.state = self.RIGHT_RUN

    def draw(self):
        self.image.clip_draw(self.frame * 100, 0, 100, 100, self.x, self.y)


