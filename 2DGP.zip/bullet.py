from pico2d import *
import random


class Bullet:
    hit_sound = None

    def __init__(self):
        self.image = load_image('resource\\weapon\\bullet3.png')
        self.speed = 100  # 100pixel per second
        self.bullet_x, self.bullet_y = 0, 0
        self.throw = False
        self.thx, self.thy = 0, 0
        self.bullet_time = 0
        self.frame = random.randint(0, 9)
        if Bullet.hit_sound == None:
            Bullet.hit_sound = load_wav('resource\\music\\hit.wav')
            Bullet.hit_sound.set_volume(32)

    def update(self, frame_time):
        self.bullet_time += frame_time

        self.frame = (self.frame + 1) % 9
        self.thx += 5
        self.bullet_x = self.thx
        self.bullet_y = self.thy

    def starboom(self, dogx, dogy):
        self.throw = True
        self.thx, self.thy = dogx, dogy

    def hitsound(self, hit):
        self.hit_sound.play()

    def draw(self):
        if self.throw == True:
            self.image.draw(self.bullet_x, self.bullet_y)
            if self.bullet_time > 2:
                self.throw = False

    def draw_bb(self):
        draw_rectangle(*self.get_bb())
        pass

    def get_bb(self):
        return self.bullet_x - 50, self.bullet_y - 50, self.bullet_x + 50, self.bullet_y + 50

