from pico2d import *
import random
import time

#from character import Dog, Cat, Boss
from character import *
from background import Background, Background2, BossBrick, Bomb, BossPlatform, UI, BossStage, Skill
from bullet import Bullet
from item import Candy
import scroll_state
import pause_state
import game_framework
import title_state
import GameOver

name = "boss_state"
image = None

cat = None
dog = None
bomb = None
background = None
skill = None
create_brick = None
bullet = None
item = None
ui = None
platform = None
num = 0
unhit_time = 0
boss = None
num2 = 0


def create_world():
    global cat, background, font, dog, bomb, bullet, platform, ui, boss, create_brick, skill

    font = load_font('NanumPen.TTF', 50)
    background = BossStage(1366, 450)
    dog = Dog()
    bomb = Bomb()
    platform = BossPlatform(1366, 45)
    create_brick = [BossBrick() for wall in range(300)]

    bullet = []
    ui = UI()
    boss = Boss()
    skill = Skill()


def destroy_world():
    global background, dog, bomb, bullet, platform, ui, boss, create_brick, skill

    del (background)
    del (dog)
    del (bomb)
    del (bullet)
    del (platform)
    del (ui)
    del (boss)
    del (create_brick)
    del (skill)


def enter():
    game_framework.reset_time()
    create_world()


def exit():
    destroy_world()


def pause():
    pass


def resume():
    pass


def handle_events(frame_time):
    global bullet, num

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        else:
            if (event.type, event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
                game_framework.quit()
            elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_SPACE):
                if dog.state == dog.RUN and dog.JUMP:
                    if bomb.bomb_count >= 0:
                        bomb.bombsound(bomb)
                        bomb.starboom(dog.x, dog.y)
                        bomb.bomb_time = 0
            elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_x):
                bullet.append(Bullet())
                bullet[num].starboom(dog.x, dog.y)
                num += 1
            elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_p):
                game_framework.push_state(pause_state)
            elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_t):
                pass
            else:
                dog.handle_event(event)


def collide(a, b):
    left_a, bottom_a, right_a, top_a = a.get_bb()
    left_b, bottom_b, right_b, top_b = b.get_bb()

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a < bottom_b: return False
    if bottom_a > top_b: return False

    return True


def update(frame_time):
    global unhit_time
    ui.update(frame_time)
    dog.update(frame_time)

    for i in bullet:
        i.update(frame_time)

    for hit in bullet:
        if (1200 <= hit.bullet_x < 1220 and 45 <= hit.bullet_y <= 373):
            if collide(boss, hit):
                hit.hitsound(hit)
                dog.score += 50
                if boss.hp > 0:
                    boss.hp -= 10
                elif boss.hp <= 0:
                    boss.hp = 0
                hit.throw = False
    for wall in create_brick:
        if 600 <= wall.x < 700:
            if collide(dog, wall):
                dog.hit_func()

        wall.update(frame_time)

    if collide(bomb, boss):
        if boss.hp > 0:

            dog.score += 50
            boss.hp -= 10
        elif boss.hp <= 0:
            boss.hp = 0
    if collide(dog, skill):
        if 0 < boss.hp <= 400:
            dog.hit_func()
    if boss.hp <= 500:
        skill.update(frame_time)
    bomb.update(frame_time)

    # if background.next_stage==0:
    background.update(frame_time)
    # elif background.next_stage==1:
    #    game_framework.push_state(Boss)

    platform.update(frame_time)

    boss.update(frame_time)

    if dog.state == Dog.DIE:
        game_framework.change_state(title_state)

    if boss.state == Boss.DEAD:
        game_framework.change_state(GameOver)


def draw(frame_time):
    clear_canvas()
    background.draw()
    dog.draw()
    bomb.draw()
    platform.draw()
    for i in bullet:
        i.draw()

    for wall in create_brick:
        if 0 <= wall.x < 1220:
            wall.draw()
    font.draw(600, 430, '2012182022', (255, 255, 255))
    font.draw(130, 320, '%d' % bomb.bomb_count, (255, 255, 255))
    font.draw(1150, 430, 'Score %3.2f' % (dog.score + scroll_state.dog.score), (255, 255, 255))
    font.draw(1150, 400, 'HP = %d' % boss.hp, (random.randint(0, 255), 255, 255))
    # for candy in item:
    #   if 0<=candy.x<1366:
    #    candy.draw()
    ui.hpdraw(dog.hp - (10 - scroll_state.dog.hp))
    ui.draw()
    boss.draw()
    if 0 < boss.hp <= 400:
        skill.draw()

    update_canvas()
